import time
import random

prizes = ["Shinny Shoe", "Sparkling Neklace", "A worn out watch"]

while True:
    answer = input("Would you like to play? (yes/no) ")

    if answer.lower().strip() == "yes":

        answer = input("you open a door,do you go right or left (left/right)")
        if answer == "left":
            answer = input("There is a nun would you like to run or attack")

            if answer == "attack":
                print("you attack with your fist")
                time.sleep(2)
                print("The nun strikes you with a cross")
                time.sleep(1)
                print("you died, GAME OVER")
            elif answer == "run":
                print("Great Job You escaped outside.")

                answer = input("Would you like to take the cars or the bike")

                if answer == "cars":
                    answer = input("there is a red and a blue car,Pick One?")

                    if answer == "blue":
                        print("You get in the car and start it")
                        time.sleep(1)
                        print("you start driving")
                        answer = input("Want to go straight or right?")

                        if answer == "right":
                            print("you turned to fast and flipped")
                            time.sleep(4)
                            print("you died in the car accident")
                            time.sleep(2)
                            print("Game OVER!!!")

                        elif answer == "straight":
                            print("you drive off into the sunset.")
                            time.sleep(1)
                            print("YOU WIN!!")
                            time.sleep(2)
                            print("here is your prize")
                            print(random.choice(prizes))

                    elif answer == "red":
                        print("you try to crank the car but it wont crank")
                        time.sleep(2)
                        print("the nun catches up to you and kills you")
                        time.sleep(3)
                        print("you lose")

                elif answer == "bike":
                    print("you start pedaling")
                    time.sleep(3)
                    print("One of the tires go flat and you fall off")
                    time.sleep(1)
                    print("The nun catches up to you and kill you")
                    print("GAME OVER")
                    time.sleep(2)

                else:
                    print("Invalid Option You Lose!!")

            else:
                print("Invalid Choice you Lose!!!")

        elif answer == "right":
            print("you walk blindly into a floor trap, YOU LOSE!!! ")

        else:
            print("Invalid choice, you lose")

    elif answer == "no":
        print("Aww Thats to Bad")

    else:
        print("Incorrect Choice")
